# Worker Payment Slips

This project fulfills the assignment requirements by generating payment slips for at least 400 workers, dynamically creating the worker list, using loops and conditionals to assign levels, and including exception handling.

## Files

- `w_p.py`: Python implementation
- `w_p.R`: R implementation
- `README.md`: This file

## Requirements

- Python 3.x with random module
- R with base packages

## Running the Code

### Python
```bash
python w_p.py
```

### R
```bash
Rscript w_p.R
```

## Assignment Description

The program:
- Uses variables to create a list of workers dynamically (at least 400 workers).
- Utilizes a for loop to generate payment slips for each worker.
- Implements conditional statements:
  - If salary > $10,000 and < $20,000, assign level "A1".
  - If salary > $7,500 and < $30,000 and employee is female, set level "A5-F".
- Adds exception handling to address potential errors.
- Converted from Python to R.