import random

#this function create the list of workers 
def create_workers(workers_count):
    workers = []
    for w in range(1, workers_count + 1):
        slry = random.randint(5000, 40000)
        gndr = random.choice(['M', 'F'])
        workers.append({
            'name': f"Worker {w}",
            'salary': slry,
            'gender': gndr
        })
    return workers

#this function i created to assign the level to the workers
def get_worker_level(slry, gndr):
    if 10000 < slry < 20000:
        return "A1"
    if 7500 < slry < 30000 and gndr == 'F':
        return "A5-F"
    return None

workers_count = 400
worker = create_workers(workers_count)

#using this loop to print workers and their level 
for w in worker:
    level = get_worker_level(w['salary'], w['gender'])
    if level:
        print(f"{w['name']}: ${w['salary']}, {w['gender']}, Level {level}")
    else:
        print(f"{w['name']}: ${w['salary']}, {w['gender']}, Level N/A")
