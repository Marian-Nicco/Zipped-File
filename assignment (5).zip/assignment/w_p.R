# create some sample worker
num_workers <- 400
worker_names <- paste("Worker", 1:num_workers)
worker_salaries <- sample(5000:40000, num_workers, replace = TRUE)
worker_genders <- sample(c("M", "F"), num_workers, replace = TRUE)

# put everything into a data frame
workers <- data.frame(
  name = worker_names,
  salary = worker_salaries,
  gender = worker_genders,
  stringsAsFactors = FALSE
)

# simple function to figure out worker level
get_worker_level <- function(salary, gender) {
  if (salary > 10000 && salary < 20000) {
    return("A1")
  } else if (salary > 7500 && salary < 30000 && gender == "F") {
    return("A5-F")
  } else {
    return(NA)
  }
}

# print out results
for (i in 1:nrow(workers)) {
  w <- workers[i, ]
  level <- get_worker_level(w$salary, w$gender)
  
  if (is.na(level)) {
    cat(w$name, "- Salary:", w$salary, "- Gender:", w$gender, "- Level: N/A\n")
  } else {
    cat(w$name, "- Salary:", w$salary, "- Gender:", w$gender, "- Level:", level, "\n")
  }
}
