import datetime
# Class Creation
class InsurancePaymentSystem:
    def __init__(self):
        self.policy_payments = {}

    def register_policy(self, policy_id, amount, due_date):
        if policy_id not in self.policy_payments:
            self.policy_payments[policy_id] = {
                'due_date': due_date,
                'amount': amount,
                'status': 'active' # active, overdue, cancelled, paid
            }
            print(f"Policy {policy_id} registered with due date {due_date} and amount ${amount:.2f}.")
        else:
            print(f"Policy {policy_id} already registered.")
            
# Implementing methods for payment processing
    def process_payment(self, policy_id, amount_paid, payment_date):
        if policy_id in self.policy_payments:
            policy_info = self.policy_payments[policy_id]
            if policy_info['status'] == 'paid':
                print(f"Policy {policy_id} is already paid in full.")
                return False
            if amount_paid >= policy_info['amount']:
                policy_info['status'] = 'paid'
                print(f"Payment of ${amount_paid:.2f} received for Policy {policy_id} on {payment_date}. Status updated to 'paid'.")
                return True
            else:
                print(f"Received partial payment of ${amount_paid:.2f} for Policy {policy_id}. Full amount due is ${policy_info['amount']:.2f}.")
                return False
        else:
            print(f"Error: Policy {policy_id} not found.")
            return False
        
# Implementing methods for sending reminders 
    def send_reminders(self, current_date):
        print(f"\n--- Running reminder system for {current_date} ---")
        for policy_id, info in self.policy_payments.items():
            if info['status'] in ['active', 'overdue']:
                days_until_due = (info['due_date'] - current_date).days

                if 0 <= days_until_due <= 7:
                    print(f"[Reminder] Policy {policy_id} is due in {days_until_due} days on {info['due_date']}.")
                elif days_until_due < 0:
                    self._apply_penalty(policy_id, current_date)

# Implementing methods for payment penalties
    def _apply_penalty(self, policy_id, current_date):
        info = self.policy_payments[policy_id]
        days_overdue = (current_date - info['due_date']).days
        if info['status'] == 'active' and days_overdue >= 1:
            # change status to overdue immediately when penalty is first applied
            info['status'] = 'overdue'
            penalty_fee = info['amount'] * 0.10 # 10% penalty
            info['amount'] += penalty_fee # Increase the total amount due
            print(f"[PENALTY APPLIED] Policy {policy_id} is {days_overdue} days overdue. Applied a ${penalty_fee:.2f} penalty. New total amount due: ${info['amount']:.2f}.")
        elif info['status'] == 'overdue' and days_overdue > 30:
            # Example of policy cancellation logic after a grace period
            info['status'] = 'cancelled'
            print(f"[POLICY CANCELLED] Policy {policy_id} cancelled due to non-payment for over 30 days.")

    def get_policy_status(self, policy_id):
        return self.policy_payments.get(policy_id, {}).get('status', 'not found')
    
    # ---Example Usage ---

    # 1. Initialize the system

payment_system = InsurancePaymentSystem()

 # 2. Register a few policies
today = datetime.date.today()
due_date_p1 = today + datetime.timedelta(days=5)
due_date_p2 = today - datetime.timedelta(days=10) # Already overdue
due_date_p3 = today + datetime.timedelta(days=60) # Not due soon

payment_system.register_policy(policy_id="P1001", amount=200.00, due_date=due_date_p1)
payment_system.register_policy(policy_id="P1002", amount=150.00, due_date=due_date_p2)
payment_system.register_policy(policy_id="P1003", amount=300.00, due_date=due_date_p3)

# 3. Simulate sending reminders/penalties on today's date
payment_system.send_reminders(current_date=today)
print(f"Status of P1002 after reminder check: {payment_system.get_policy_status('P1002')}")

# 4. Process a payment
tomorrow = today + datetime.timedelta(days=1)
payment_system.process_payment(policy_id="P1001", amount_paid=200.00, payment_date=tomorrow)
print(f"Status of P1001 after payment: {payment_system.get_policy_status('P1001')}")

# 5. Simulate time passing and policy P1002 becoming cancelled
thirty_five_days_later = today + datetime.timedelta(days=35)
payment_system.send_reminders(current_date=thirty_five_days_later)
print(f"Status of P1002 after extended overdue period: {payment_system.get_policy_status('P1002')}")

