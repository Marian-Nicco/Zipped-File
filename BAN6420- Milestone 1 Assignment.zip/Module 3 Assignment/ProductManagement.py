# Class Creation
class Products:
    def __init__(self):
        self.products ={}

     # Implementing methods for creating policy products   
    def create_product(self, product_id, name, coverage_type, premium_amount, is_active=True):
        if product_id in self.products:
            print(f"Error: Product ID '{product_id}' already exist.")
            return None
        new_product ={
            'product_id': product_id,
            'name': name,
            'coverage_type': coverage_type,
            'premium_amount': premium_amount,
            'is_active': is_active,
            'status': 'Active' if is_active else 'Suspended'
        }
        self.products[product_id] = new_product
        print(f"Product '{name}' created successfully.")
        return new_product
    
    # Implementing methods for updating policy products
    def update_product(self, product_id, **kwargs):  # This funtion update attributes of an existing insurance product.
        if product_id not in self.products:
            print(f"Error: Product ID '{product_id}' not found.")
            return None
        product = self.products[product_id]
        for key, value in kwargs.items():
            if key in product:
                product[key] = value

        # Ensure status reflects is_active state
        if 'is_active' in kwargs:
            product['status'] ='Active' if kwargs['is_active'] else 'Suspended'

        print(f"product '{product['name']}' updated successfully.")
        return product
    
    # Implementing methods for suspending policy products
    def suspend_product(self, product_id):  # This function suspends a product(marked as inactive), inorder to prevent new policies from being issued under this product.
        if product_id not in self.products:
            print (f"Error: Products ID '{product_id}' not found.")
            return False
        
        product = self.products[product_id]
        if product['is_active']:
            product['is_active'] = False
            product['status'] = 'Suspended'
            print(f"Product '{product['name']}' suspended successfully.")
            return True
        else:
            print(f"Product '{product['name']}' is already suspended.")
            return False
    def get_product_details(self, product_id):  # Retrieves details for a specific product.
        return self.products.get(product_id, None)
    
    def list_all_products(self):  # This gives a list of all products currently managed.
        return list(self.products.values())
    
        
# ---Example Usage ---
if __name__ =='__main__':
    manager = Products()

    # 1. Create a product
    manager.create_product(
        product_id='P001',
        name='Basic Auto Plan',
        coverage_type='Auto'
        premium_amount=150.75
    )
    manager.create_product(
        product_id='P002',
        name='Deluxe Home Shield',
        coverage_type='Home',
        premium_amount=450.00
    )
    # Attempt to create duplicate ID
    manager.create_product(
        product_id='P001',
        name='Another Plan',
        coverage_type='Life',
        premium_amount=99.99
    )
    print("\n--- Current Products ---")
    for prod in manager.list_all_products():
        print(prod)
    
# 2. Update a product
    manager.update_product(
        product_id='P001',
        premium_amount=165.00,
        name='Revised Basic Auto Plan'
    )
    print("\n--- Products After Update ---")
    print(manager.get_product_details('P001'))

# 3. Suspend a product
    manager.suspend_product(product_id='P002')

    print("\n--- Products After Suspension ---")
    for prod in manager.list_all_products():
        print(prod)
