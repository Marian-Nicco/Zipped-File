# Task 1: Class Creation:
class Policyholder:
    def  __init__(self, name, email, policy_number, status='active'):
        self.name = name
        self.email = email
        self.policy_number = policy_number
        self.status = status

        def __str__(self):
            return f'Policyholder: {self.name}(Policy Num: {self.policy_number}, Status: {self.status})'
        
        # Task 2: 
        # Implementing Method 1 (Register Policyholder)
        def register(self, name, email, policy_number):
            print(f'Registering new policy holder: {name}')
            return self(name, email, policy_number, status='active')
        
        
        # Implementing Methods 2 (Suspend Policyholder)
        def suspend(self):
            if self.status == 'active':
                self.status = 'suspended'
                print(f'Policy holder {self.name} (policy number: {self.policy_number}) has been suspended.')
            else:
                print(f'policy holder {self.name} (policy number: {self.policy_number}) is already suspended,')

        # Implementing Method 3 (Reactivate Policyholder)
        def reactivate(self):
            if self.status == 'suspended':
                self.status = 'active'
                print(f'policy holder {self.name} (policy number: {self.policy_number}) has beeen reactivated.')
            else:
                print(f'policy holder {self.name} (policy number: {self.policy_number}) is already active.')

# Create New policy holder objects
holder1 = Policyholder(policy_number=101, name="Marian Nicco", email="mariannicco@gmail.com")
holder2 = Policyholder(policy_number=102, name= "Thomas Mason", email="tgabrielmaso@gmail.com")





    



        


                 
        
        

                

