# Employee Salary Data Analysis Assignment

## What This Project Does

This project is for my data analysis assignment. It reads employee salary data from a CSV file, lets you search for employees, and saves their info to a zip file. Then there's an R script that unzips the file and shows the data.

## Files in This Project

- `Total.csv` - The salary data file that was provided
- `employee_analysis.ipynb` - My main Jupyter notebook with all the Python code
- `unzip_and_display.R` - R script that unzips and displays the employee data
- `README.md` - This file

When you run the notebook, it will create:
- `Employee Profile/` folder with CSV files
- Zip files with employee profiles

## What You Need

**For Python:**
- Python 3 (I'm using Python 3.13)
- pandas library
- That's it! The other stuff (csv, os, zipfile) comes with Python

**For R:**
- R installed on your computer
- No extra packages needed

## Setup Instructions

### Installing Python Stuff

First, make sure you have pandas:
```bash
pip install pandas
```

If that doesn't work, try:
```bash
pip3 install pandas
```

Then install Jupyter Notebook if you don't have it:
```bash
pip install notebook
```

### Installing R

Just download R from https://www.r-project.org/ and install it. Pretty straightforward.

## How to Run This

### Running the Python Notebook

1. Open your terminal and go to the project folder:
```bash
cd /path/to/assign
```

2. Start Jupyter:
```bash
jupyter notebook
```

3. Your browser should open. Click on `employee_analysis.ipynb`

4. Run the cells:
   - You can click "Cell" then "Run All" to run everything at once
   - Or just press Shift+Enter on each cell to go through them one by one

5. The notebook will:
   - Load the CSV file
   - Put all the data into a dictionary (which took me a while to figure out)
   - Create a function to search for employees
   - Test it with some example names
   - Export an employee's info to a zip file

### Running the R Script

1. Open R or RStudio

2. Make sure you're in the right folder:
```r
setwd("/path/to/assign")
```

3. Run the script:
```r
source("unzip_and_display.R")
```

The script finds the zip file, unzips it, and prints out the employee data.

## Example: How to Search for an Employee

In the notebook, you can search for anyone like this:

```python
employee_name = "NATHANIEL FORD"
employee_details = get_employee_details(employee_name)
```

It will show something like:
```
=== Employee Details for NATHANIEL FORD ===
Job Title: GENERAL MANAGER-METROPOLITAN TRANSIT AUTHORITY
Base Pay: $167411.18
Overtime Pay: $0.00
...
```

## Example: How to Export an Employee Profile

```python
export_employee_profile("NATHANIEL FORD")
```

This creates a zip file called `NATHANIEL_FORD_profile.zip` with a CSV inside.

## Some Employee Names You Can Try

- NATHANIEL FORD
- GARY JIMENEZ
- ALBERT PARDINI
- CHRISTOPHER CHONG
- PATRICK GARDNER

There are way more in the file, these are just some examples from the top.

## What the CSV Data Looks Like

The Total.csv file has these columns:
- EmployeeName
- JobTitle
- BasePay
- OvertimePay
- OtherPay
- Benefits
- TotalPay
- TotalPayBenefits
- Year

## Common Problems I Ran Into (and How I Fixed Them)

**"ModuleNotFoundError: No module named 'pandas'"**
- Just need to install pandas: `pip install pandas`

**"FileNotFoundError: Total.csv not found"**
- Make sure the Total.csv file is in the same folder as the notebook

**"No zip files found" (when running R script)**
- You need to run the Python notebook first to create a zip file

**Jupyter won't start**
- Install it: `pip install notebook`

## Assignment Requirements

Here's what the assignment asked for and where I did it:

1. Import data - Done in Step 2 of the notebook
2. Create employee function - Done in Step 4 (the get_employee_details function)
3. Use dictionary for data processing - Done in Step 3
4. Error handling - Added try/except blocks everywhere
5. Export to CSV and zip - Done in Step 6 (the export_employee_profile function)
6. R script to unzip and display - Done in the unzip_and_display.R file

## Notes

- I added a lot of comments in the code because I wanted to make sure I could understand it later
- The error messages should be pretty clear if something goes wrong
- All the variable names are simple (like employee_name, employee_dict, etc.)
- I used print statements to show what's happening at each step

If something doesn't work, check the error message - I tried to make them helpful.
