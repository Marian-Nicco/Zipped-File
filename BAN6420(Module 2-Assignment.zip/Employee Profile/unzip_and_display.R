# ============================================
# R Script to Unzip and Display Employee Data
# ============================================
# This script will:
# 1. Unzip the Employee Profile zip file
# 2. Read the CSV file inside
# 3. Display the employee data

# Clear the console (optional)
cat("\014")

# Print a welcome message
cat("=== Employee Profile Unzip and Display Script ===\n\n")

# Step 1: Set the working directory
# Make sure this script is in the same folder as your zip files
cat("Step 1: Checking current directory...\n")
current_dir <- getwd()
cat("Current directory:", current_dir, "\n\n")

# Step 2: List all zip files in the directory
cat("Step 2: Looking for zip files...\n")

# Try to find zip files with error handling
tryCatch({
  # Get list of all zip files
  zip_files <- list.files(pattern = "\\.zip$")
  
  # Check if any zip files were found
  if (length(zip_files) == 0) {
    cat("Error: No zip files found in the current directory.\n")
    cat("Please make sure you have exported an employee profile first.\n")
    stop("No zip files found")
  }
  
  # Show the zip files found
  cat("Found", length(zip_files), "zip file(s):\n")
  for (i in 1:length(zip_files)) {
    cat(i, ".", zip_files[i], "\n")
  }
  
  # Use the first zip file
  zip_file_to_use <- zip_files[1]
  cat("\nUsing zip file:", zip_file_to_use, "\n\n")
  
}, error = function(e) {
  cat("Error listing files:", e$message, "\n")
  stop()
})

# Step 3: Unzip the file
cat("Step 3: Unzipping the file...\n")

# Create output folder name
output_folder <- "Unzipped_Employee_Profile"

# Try to unzip with error handling
tryCatch({
  # Check if output folder exists, if yes, remove it first
  if (dir.exists(output_folder)) {
    cat("Removing old output folder...\n")
    unlink(output_folder, recursive = TRUE)
  }
  
  # Create the output folder
  dir.create(output_folder)
  
  # Unzip the file
  unzip(zip_file_to_use, exdir = output_folder)
  
  cat("Successfully unzipped to:", output_folder, "\n\n")
  
}, error = function(e) {
  cat("Error unzipping file:", e$message, "\n")
  stop()
})

# Step 4: Find and read the CSV file
cat("Step 4: Reading the CSV file...\n")

tryCatch({
  # List all CSV files in the unzipped folder
  csv_files <- list.files(output_folder, pattern = "\\.csv$", full.names = TRUE)
  
  # Check if any CSV files were found
  if (length(csv_files) == 0) {
    cat("Error: No CSV files found in the unzipped folder.\n")
    stop("No CSV files found")
  }
  
  # Use the first CSV file
  csv_file_to_read <- csv_files[1]
  cat("Found CSV file:", basename(csv_file_to_read), "\n\n")
  
  # Read the CSV file
  employee_data <- read.csv(csv_file_to_read)
  
  cat("Successfully read the CSV file!\n\n")
  
}, error = function(e) {
  cat("Error reading CSV file:", e$message, "\n")
  stop()
})

# Step 5: Display the employee data
cat("Step 5: Displaying the employee data...\n")
cat("========================================\n\n")

tryCatch({
  # Print the data in a nice format
  cat("EMPLOYEE PROFILE DATA:\n")
  cat("----------------------\n\n")
  
  # Loop through each row and print it
  for (i in 1:nrow(employee_data)) {
    field_name <- employee_data[i, 1]
    field_value <- employee_data[i, 2]
    
    # Print each field
    cat(sprintf("%-25s: %s\n", field_name, field_value))
  }
  
  cat("\n========================================\n")
  cat("Data displayed successfully!\n\n")
  
  # Also print as a dataframe for better view
  cat("Data as table:\n")
  print(employee_data)
  
}, error = function(e) {
  cat("Error displaying data:", e$message, "\n")
})

# Print completion message
cat("\n=== Script completed successfully! ===\n")
