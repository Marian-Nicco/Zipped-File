class PolicyholderManager: # This calss manages policyholder records including registration, suspension, and reactiuvation.
    def __init__(self):
        self.policyholders = {}
    def register(self, policy_id, name): # This method registers a new policyholder with an 'ACTIVE' status if the ID is unique.
        if policy_id in self.policyholders:
            print(f"Error: Policy ID {policy_id} already exist.")
            return False
        
        self.policyholders[policy_id] ={
            'name': name,
            'status': 'ACTIVE'
        }
        print(f"Registered new policyholder: {name} with ID {policy_id}.")
        return True
    

    def _update_status(self, policy_id, new_status): # This is an helper method to change the status of an existing policyholder.
        if policy_id not in self.policyholders:
            print(f"Error: Policy ID {policy_id} not found.")
            return False
        
        current_status = self.policyholders[policy_id]['status']
        if current_status == new_status:
            print(f"Info: Policyholder {policy_id} is already {new_status}.")
            return False
        self.policyholders[policy_id]['status'] = new_status
        print(f"Policyholder {policy_id} status changed from {current_status} to {new_status}.")
        return True
    

    def suspend(self, policy_id): # This method suspends an active policyholder.
        return self._update_status(policy_id, 'SUSPENDED')
    
    
    def reactivate(self, policy_id): # This method reactivates a suspended policyholder.
        return self._update_status(policy_id, 'ACTIVE')

    def display_policyholders(self): # This function print the current list of all policyholders and their statuses.
        print("\nCurrent Policyholders:")
        if not self.policyholders:
            print("No records found.")
        for policy_id, details in self .policyholders.items():
            print(f" ID: {policy_id}, Name: {details['name']}, Status: {details['status']}")
            print("-" * 20)

#--- Example Usage ---
manager = PolicyholderManager()

# 1. Register new policyholders
manager.register(101, "Marian Nicco")
manager.register(102, "Jimas Jacoby")
manager.register(103, "Thomas Mason") 

manager.display_policyholders()

# 2. Suspend a policyholder
manager.suspend(102)
manager.suspend(999) # Fails due to non-existent ID

manager.display_policyholders()

# 3. Reactivate a policyholder
manager.reactivate(102)
manager.reactivate (101) # Fails/gives info message because Marian is already active

manager.display_policyholders()

        


