class PolicyHolder:
    def __init__(self, name, policy_id, product, paid=False):
        self.name = name
        self.policy_id = policy_id
        self.product = product
        self.paid = paid
        self.active = True

    def register(self):
        if self.active:
            print(f"{self.name} is already registered.")
        else:
            self.active = True
            print(f"{self.name} has been registered.")

    def suspend(self):
        if not self.active:
            print(f"{self.name} is already suspended.")
        else:
            self.active = False
            print(f"{self.name} has been suspended.")

    def reactivate(self):
        if self.active:
            print(f"{self.name} is already active.")
        else:
            self.active = True
            print(f"{self.name} has been reactivated.")

    def display_details(self):
        status = "Active" if self.active else "Suspended"
        payment_status = "Paid" if self.paid else "Not Paid"
        print(f"""
======================================
 Policy Holder Details
--------------------------------------
 Name:           {self.name}
 Policy ID:      {self.policy_id}
 Product:        {self.product}
 Status:         {status}
 Payment Status: {payment_status}
======================================
        """)

# Create policyholders who have paid
holder1 = PolicyHolder("Marian Nicco", "101", product="Revised Basic Auto Plan", paid=True)
holder2 = PolicyHolder("Jimas Jacoby", "102", product="Deluxe Home Shield", paid=True)

# Display account details
holder1.display_details()
holder2.display_details()

